# Independent DITO research handover

Prepared for a new repository on 2026-11-01 UTC from the DITO research workspace.
This repository preserves the portable handover and its live findings journal.
It has a fresh Git history and contains no parent repository history or installed dependencies.

Start with [the handover guide](dito-system-handoff/README.md),
[verification limits](dito-system-handoff/docs/04-VERIFICATION.md), and
[the live findings journal](dito-system-handoff/findings/README.md).

## What this export contains

- The original October 25 reference application, API inventory, documentation and historical evidence, preserved without rewriting the frozen snapshot.
- The live journal copied at export time, including later research observations.
- The automatic findings recorder and repository working agreement.

The journal includes October 29 catalog-comparison findings. The executable reference
application remains the October 25 snapshot: later dashboard source changes and the
DVendo Supply application are separate from this handover export. Historical evidence
locations identify the original workspace and are not all included files.

## Validate the preserved package

Use Node.js 24 or later, from this repository root:

```sh
node dito-system-handoff/tools/verify-handoff.mjs
```

For running the reference application, follow [setup](dito-system-handoff/docs/01-SETUP.md).
For a new observation, send sanitized JSON on stdin to:

```sh
node dito-system-handoff/tools/research/record-finding.mjs
```

Read [the schema and workflow](dito-system-handoff/docs/06-AUTOMATIC-FINDINGS.md).
Record new evidence in the journal; retain the original reference and historical ledger.
Native lifecycle hooks are not installed by this export.

## Scope and next project

This is a completed research handover, not a production purchasing application.
Successful live payment, recipient fulfillment, and Long Expiry offer discovery remain
unverified. Mock tests do not establish successful live transactions.

The previously planned fresh supplier/manager application is DVendo Supply, a separate
starter project. Publishing this research repository does not deploy either application.
