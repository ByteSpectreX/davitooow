# Working agreement

Read [the project map](docs/01-project-map.md), [product rules](docs/03-product.md), [evidence status](research/README.md) and [live findings](research/findings/README.md) before substantive work.

## Standing authorization for routine work

The owner authorizes routine, reversible work needed to complete the requested task without repeated confirmation. Proceed with reading and searching project files, creating and editing source and documentation, running local builds, lint checks and mocked tests, starting local preview servers, and reading public documentation. Keep these actions within the requested task and report meaningful changes and verification results.

Ask for explicit approval of the concrete action and target before:

- Deleting project files or directories, user data, databases, accounts, or remote resources; destructive cleanup; or overwriting unrelated work.
- Deploying, publishing, releasing, or changing production services, infrastructure, DNS, or live configuration.
- Creating purchases, payments, paid resources, subscriptions, or other financial commitments, or retrying an ambiguous financial submission.
- Requesting OTPs, exporting credentials or private account data, rotating secrets, or changing account access, authentication, security controls, or approval settings.
- Pushing or merging changes to shared repositories, force-pushing, rewriting history, or performing destructive Git operations.
- Sending messages or transferring private information to external services or people.

An explicit approval applies only to its stated action, target, and scope; do not ask again for that same approved action while those remain unchanged. General authorization for routine work does not authorize the actions above. If the impact is uncertain, inspect it first and ask before proceeding with a potentially destructive, external, or costly effect.

These instructions express the owner's workflow preferences; they do not change the host's tool approvals, sandbox, managed policy, or hook trust. Use supported client permission settings for automatic approval review. Honor denied actions and host restrictions without attempting a workaround.

## Project requirements

- Record meaningful decisions, corrections, failures and results using `node scripts/record-finding.mjs` with sanitized structured JSON on stdin. The schema and example are in [the evidence guide](research/README.md). Tests record results automatically through `npm test`.
- Keep imported historical source evidence intact. Add current evidence to the journal. An imported implementation or mock pass is never proof of a live payment or recipient delivery.
- Keep the documented API contract aligned with implemented routes. Proposed routes stay in the design guide until implemented and tested.
- Enforce server-side manager scope before adding private API operations. UI role selection is a demo feature, not authentication.
- Store payer account and recipient SIM separately. Persist financial intent before submission, coordinate by supplier wallet and reconcile unknown results before any retry.
- No credentials, OTPs, cookies, tokens, raw account responses or real mobile numbers in source, notes or logs. No provider request from the browser.
- Documentation, coding and query authorization do not authorize OTPs, purchases, ambiguous payment retries, deployment or credential export.
- Run `npm test`, `npm run build` and `npm run verify` as appropriate. For Worker changes, additionally run the Cloudflare dry run after installing tooling. Keep staging separate from existing production resources.
