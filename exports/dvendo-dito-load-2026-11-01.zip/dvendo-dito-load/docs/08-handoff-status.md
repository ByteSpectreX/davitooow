# Repository transfer and current status

The owner selected **dvendo-dito-load** as the independent repository for the supplier/manager
application: [ByteSpectreX/dvendo-dito-load](https://github.com/ByteSpectreX/dvendo-dito-load).
This project was prepared from the DVendo Supply starter in the original DITO research
workspace. Only this standalone application and relevant sanitized research are transferred;
the original repository and full DITO research handover retain their own history.

## What is ready

- Editable synthetic supplier/manager UI and its generated preview.
- Health/capability Worker API, implemented OpenAPI contract and offline tests.
- Product responsibilities, planned data/API architecture and phased build roadmap.
- All 33 historical DITO endpoint records, historical verification limits and provenance.
- Automatic sanitized findings recording and the owner's routine-work authorization boundaries.
- [October 29 Long Expiry research](../research/updates/2026-10-29-long-expiry.md) and
  [links to the later dashboard implementation](../research/updates/README.md).

## What still needs implementation

Authentication, persistent business records, live DITO read integration, verified
supplier-wallet recipient fulfillment and automatic renewals are not implemented.
The UI uses fictional data and resets on reload. A mock pass is not a live account result,
completed payment or delivered promo. Long Expiry 799 still has no verified exact offer ID.

Follow [the roadmap](07-roadmap.md): implement authenticated supplier/manager membership
and server-side assignment scope first, then persistent records before live integration.
Provider experiments, OTPs, purchases and deployment need separate explicit authorization.

## Local development

Use Node.js 24 or later:

```sh
npm run build
npm test
npm run verify
npm run dev
```

The local preview is at `http://localhost:5180`. The build, tests and project verification
need no installed dependencies. Cloudflare tooling uses the pinned lockfile through `npm ci`.
The existing staging resource names are configuration only; the repository transfer does
not provision, deploy or change any Cloudflare resources.
