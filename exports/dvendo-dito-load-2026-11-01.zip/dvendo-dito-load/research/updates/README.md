# Research updates after the starter baseline

[Long Expiry investigation and catalog-comparison findings](2026-10-29-long-expiry.md)
were copied without modification from the original research workspace. Their statements
remain dated research evidence; this transfer does not verify current offers or purchases.

The latest original dashboard source is preserved in the original repository at
[commit b1c84ac](https://github.com/ByteSpectreX/davitooow/tree/b1c84ac/dito-login-test).
Its [catalog-comparison implementation](https://github.com/ByteSpectreX/davitooow/blob/b1c84ac/dito-login-test/src/promo-research.mjs)
is a reference for future backend read integration. It is not wired into this application.

Keep the [historical import manifest](../import-manifest.json) unchanged.
New observations belong in [the live findings journal](../findings/README.md).
