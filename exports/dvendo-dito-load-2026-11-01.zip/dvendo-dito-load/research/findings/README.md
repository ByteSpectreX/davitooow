# Live research findings

New discoveries, failed tests, corrections, and unresolved questions are recorded here automatically by the research workflow. The reference snapshot and its historical verification ledger remain separate.

A mock-tested pass does not establish a live account result or payment success. Records are sanitized summaries, not raw transcripts or account responses.

| UTC date | Finding | Evidence | Outcome |
| --- | --- | --- | --- |
| 2026-11-01 | [Fresh Git export passes standalone rebuild, offline tests and provenance verification](./records/66de374cc9e8aca22fc29e6e.json) | mock-tested | passed |
| 2026-11-01 | [Independent Git transfer normalizes editable text while preserving research bytes](./records/8065ac78aa93775b7f5ac2ac.json) | code-observed | passed |
| 2026-11-01 | [dvendo-dito-load prepared as an independent application repository; GitHub transfer awaits access](./records/e9e5603e32368ce7479bf075.json) | code-observed | observed |
| 2026-11-01 | [Clean project offline test result](./records/582c2a590d1ecdb1d55b6cbe.json) | mock-tested | passed |
| 2026-10-26 | [Clean transfer archive independently builds and passes offline checks outside original checkout](./records/9229f3a2c17ae7902be155e0.json) | mock-tested | passed |
| 2026-10-26 | [DVendo Supply foundation is locally verified but not production-complete](./records/9aa250dd9fbb2fca22e97e70.json) | mock-tested | observed |
| 2026-10-26 | [Portable clean-project foundation prepared and verified](./records/d1f9c1c12ef76966ffb1fede.json) | mock-tested | observed |
| 2026-10-26 | [Clean project offline test result](./records/45b60aaffc7a576afa234796.json) | mock-tested | passed |
| 2026-10-26 | [Clean project offline test result](./records/43771bfb974475a3eaeedf86.json) | mock-tested | passed |
